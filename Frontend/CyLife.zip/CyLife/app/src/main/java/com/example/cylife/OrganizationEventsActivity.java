package com.example.cylife;

public class OrganizationEventsActivity {
}
